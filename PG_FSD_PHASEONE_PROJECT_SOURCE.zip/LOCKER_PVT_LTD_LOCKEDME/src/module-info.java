module locker.lockedme.com {
	exports locker.lockedme.com;
}